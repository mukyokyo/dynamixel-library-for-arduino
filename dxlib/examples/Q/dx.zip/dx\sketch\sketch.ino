#include <Arduino_RouterBridge.h>
#include "dx2lib.h"
#include "whoareyou.h"

const DX2LIB::TDXHost_ConfParam param = {
  [](uint32_t baud) {
    Serial.begin(baud);
    return baud;
  },
  [] {
    Serial.end();
  },
  [](uint32_t baud) {
    Serial.begin(baud);
    return baud;
  },
  [](uint32_t timeout) {
    Serial.setTimeout(timeout);
    return timeout;
  },
  [] {
    while (Serial.available()) Serial.read();
  },
  [](uint8_t c) {
    Serial.write(c);
  },
  [](const uint8_t *buf, int len) {
    Serial.write(buf, len);
  },
  [](uint8_t *buf, int len) {
    if (len == 0) return 0;
    return (int)Serial.readBytes(buf, len);
  },
  [] {
    Serial.flush();
  }
};

DX2LIB dxif ((DX2LIB::TDXHost_ConfParam *)&param);

#define _ADDR_ID        (7)

#define MAX(a,b) ((a) > (b) ? a : b)
#define MIN(a,b) ((a) < (b) ? a : b)

void setup() {
  dxif.begin (57600, 50);

  pinMode(LED_BUILTIN, OUTPUT);
  Monitor.begin (115200);
  while (!Monitor && millis() < 10000) {
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    delay(50);
  }
  delay(3000);
  Monitor.println("connected");
}

// Discard of incoming data
void DiscardRxData (void) {
  delay (100);
  do {
    if (Monitor.available() > 0) Monitor.read();
  } while (Monitor.available() > 0);
}

// Numeric input only
bool InputNum (int32_t *num) {
  int i = 0;
  char buf[100], ch = 0;

  while ((ch != 0x0d) && (ch != 0x0a)) {
    if (Monitor.available() > 0) {
      ch = Monitor.read();
      if (ch >= '0' and ch <= '9') {
        Monitor.print (ch);
        buf[i++] = ch;
      }
    }
  }
  buf[i] = 0;
  DiscardRxData();
  *num = atoi (buf);
  return (strlen (buf));
}

// Yes or No
bool YorN (void) {
  char ch;
  while (Monitor.available() == 0);
  ch = toupper (Monitor.read());
  DiscardRxData();
  return (ch == 'Y');
}

// Persistent search for devices with specified ID
bool DeviceExists (uint8_t id) {
  bool detected = false;
  for (int i = 0; i < 5; i++) {
    if ((detected = dxif.Ping (id, NULL))) break;
  }
  return detected;
}

void loop() {
  uint16_t modelno;
  static uint8_t id = 1;
  uint8_t b, err;
  int32_t d;
  PModelInfo pminfo = NULL;
  PMajorItemsAddr paddr = NULL;

  if (Monitor.available() > 0) {
    char ch = Monitor.read();
    DiscardRxData();

    Monitor.print (ch);
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    switch (ch) {
      case 's': // scan
        Monitor.print ("\r\nStat scan\r\n");
        for (uint8_t i = 0; i <= 252; i++) {
          if (Monitor.available() > 0) {
            DiscardRxData();
            break;
          }
          if (dxif.Ping (i, NULL)) {
            if (dxif.ReadWordData (i, 0, &modelno, NULL)) {
              PModelInfo p = whoareyou (modelno);
              Monitor.println ("");
              Monitor.print (i);
              Monitor.print (":");
              Monitor.println (p->name);
            } else Monitor.print (" ");
          } else Monitor.print (".");
        }
        break;

      case 'p': // ping
        Monitor.print ("\r\nPing to id=");
        Monitor.print (id);
        Monitor.print (dxif.Ping (id, NULL) ? " ok" : " ng");
        break;

      case 'R': // factory reset device
        if (dxif.Ping (id, NULL)) {
          Monitor.print ("\r\nFactory reset device\r\nAre you sure ?(Y/N)");
          if (YorN()) {
            Monitor.print ("y\r\n");
            if (!DeviceExists (1) || (id == 1)) {
              if (dxif.Reset (id, &err)) {
                Monitor.print ("\r\nOK\r\n");
                id = 1;
              } else {
                Monitor.print ("\r\nNG: $");
                Monitor.println (err, HEX);
              }
            } else
              Monitor.println ("NG: That setting conflicts");
          } else
            Monitor.println ("n");
        } else
          Monitor.println ("\r\nCannot fRind device");
        break;
      case 'i': // change host id
        Monitor.print ("\r\nChange host id\r\nInput id (0..252) = ");
        if (InputNum (&d))
          if (d >= 0 && d <= 252) id = d;
        break;
      case 'I':
        if (dxif.Ping (id, NULL)) {
          Monitor.print ("\r\nChange device id\r\nInput id (0..252) = ");
          if (InputNum (&d)) {
            d = MAX (MIN (d, 252), 0);
            if (!DeviceExists (d)) {
              if (dxif.WriteByteData (id, _ADDR_ID, d, &err)) {
                Monitor.print ("\r\nOK\r\n");
                id = d;
              } else {
                Monitor.print ("\r\nNG: $");
                Monitor.println (err, HEX);
              }
            } else
              Monitor.println ("NG: That setting conflicts");
          }
        } else
          Monitor.println ("\r\nCannot find device");
        break;

      case 'O': // change device operating mode
        if (dxif.Ping (id, NULL)) {
          if (dxif.ReadWordData (id, 0, &modelno, NULL)) {
            pminfo = whoareyou (modelno);
            paddr = itemaddr (modelno);

            if (dxif.ReadByteData (id, paddr->opmode.addr, &b, NULL)) {
              Monitor.print ("\r\nChange device op mode (current op mode = ");
              Monitor.print (b);
              Monitor.print (")\r\nInput op mode (0:cur 1:velo 3:pos 4:multiturn 5:multi+cur 16:PWM) = ");
              if (InputNum (&d)) {
                b = MAX (MIN (d, 16), 0);

                if (dxif.WriteByteData (id, paddr->opmode.addr, b, NULL)) {
                  Monitor.print ("\r\nOK");
                } else {
                  Monitor.print ("\r\nNG: $");
                  Monitor.print (err, HEX);
                }
              }
            }
          }
        } else
          Monitor.print ("\r\nCannot find device\r\n");
        break;

      case 'E': // change device torque enable
        Monitor.print ("\r\n");
        if (dxif.Ping (id, NULL)) {
          if (dxif.ReadWordData (id, 0, &modelno, NULL)) {
            pminfo = whoareyou (modelno);
            paddr = itemaddr (modelno);

            if (dxif.ReadByteData (id, paddr->torque_en.addr, &b, NULL)) {
              b = b ^ 1;
              if (dxif.WriteByteData (id, paddr->torque_en.addr, b, NULL)) {
                Monitor.print ("Change device torqule ");
                Monitor.print (b == 0 ? "Off" : "On");
              }
            }
          } else
            Monitor.print ("Cannot find device\r\n");
        } else
          Monitor.print ("Cannot find device\r\n");
        break;

      case 'A':
        printf ("\r\n");
        if (dxif.Ping (id, NULL)) {

          if (dxif.ReadWordData (id, 0, &modelno, NULL)) {
            pminfo = whoareyou (modelno);
            paddr = itemaddr (modelno);

            if (dxif.ReadByteData (id, paddr->opmode.addr, &b, NULL)) {

              if ((b == 3) || (b == 4) || (b == 5)) {
                if (dxif.ReadLongData (id, paddr->p_pos.addr, (uint32_t *)&d, NULL)) {

                  int32_t dblval_flg = abs(pminfo->positionlimit.max / 512);
                  while (Monitor.available() == 0) {
                    d += dblval_flg;
                    if (d > pminfo->positionlimit.max) {
                      dblval_flg *= -1;
                      d = pminfo->positionlimit.max;
                    } else if (d < pminfo->positionlimit.min) {
                      dblval_flg *= -1;
                      d = pminfo->positionlimit.min;
                    }
                    dxif.WriteLongData (id, paddr->g_pos.addr, d, NULL);
                    delay (1);
                  }
                }
                DiscardRxData();
              }
              Monitor.print ("\r\n");
            } else
              Monitor.print ("NG: op mode is different\r\n");
          }
        } else
          Monitor.print ("Cannot find device\r\n");
        break;

      case 'V':
        printf ("\r\n");
        if (dxif.Ping (id, NULL)) {

          if (dxif.ReadWordData (id, 0, &modelno, NULL)) {
            pminfo = whoareyou (modelno);
            paddr = itemaddr (modelno);

            if (dxif.ReadByteData (id, paddr->opmode.addr, &b, NULL)) {

              if ((b == 1)) {
                if (dxif.ReadLongData (id, paddr->p_velo.addr, (uint32_t *)&d, NULL)) {

                  int32_t dblval_flg = 1;
                  while (Monitor.available() == 0) {
                    d += dblval_flg;
                    if (d > 1023) {
                      dblval_flg = -1;
                      d = 1023;
                    } else if (d < -1023) {
                      dblval_flg = 1;
                      d = -1023;
                    }
                    dxif.WriteLongData (id, paddr->g_velo.addr, d, NULL);
                    delay (1);
                  }
                }
                DiscardRxData();
              }
              Monitor.print ("\r\n");
            } else
              Monitor.print ("NG: op mode is different\r\n");
          }
        } else
          Monitor.print ("Cannot find device\r\n");
        break;

    }
    Monitor.print ("\r\nid:");
    Monitor.print (id);
    Monitor.print (">");
  }
}